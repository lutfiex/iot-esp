#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"

#include "lwip/err.h"
#include "lwip/sys.h"

#include "lwip/inet.h"
#include "lwip/netdb.h"
#include "lwip/sockets.h"
#include "lwip/ip4_addr.h"
#include "lwip/dns.h"

#include "ping/ping_sock.h"

#include "global.h"
#include "wifi_config.h"
#include "util.h"
#include "uart_task.h"

#include "sdkconfig.h"



char wifiSsid[256];
char wifiPw[256];
bool isConnected=false;

esp_netif_t *my_sta;

bool hasFixedIpConfig=false;
esp_netif_ip_info_t fixedIpInfo = {0};
esp_netif_dns_info_t fixedDnsInfo1;
esp_netif_dns_info_t fixedDnsInfo2;

esp_ip4_addr_t currentIp;
esp_ip4_addr_t currentNetmask;
esp_ip4_addr_t currentGateway;
esp_netif_dns_info_t currentDnsInfo1;
esp_netif_dns_info_t currentDnsInfo2;

static EventGroupHandle_t s_wifi_event_group;

#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT      BIT1

static const char *TAG = "wifi station";

static int s_retry_num = 0;
static bool reqForceDisconnect=false;

static bool isPingStart=false;
static esp_ping_handle_t ping;

#define WIFI_CONFIG_ESP_MAXIMUM_RETRY  3

#if CONFIG_ESP_WIFI_AUTH_OPEN
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_OPEN
#elif CONFIG_ESP_WIFI_AUTH_WEP
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WEP
#elif CONFIG_ESP_WIFI_AUTH_WPA_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA2_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA2_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA_WPA2_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA_WPA2_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA3_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA3_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA2_WPA3_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA2_WPA3_PSK
#elif CONFIG_ESP_WIFI_AUTH_WAPI_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WAPI_PSK
#endif


bool tryToConnectWifi();
bool wifiConfigIsConnected(){
    return isConnected;
}

//===============================================================================================
//https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/protocols/icmp_echo.html
static void sendPingRes(uint8_t res,uint16_t seq,uint16_t time){
    UART_QUEUE_ITEM uqi;
    uint8_t msg[4];
    msg[0]=(seq>>8)&0x00ff;
    msg[1]=(seq)&0x00ff;
    msg[2]=(time>>8)&0x00ff;
    msg[3]=(time)&0x00ff;
    utilPrepareUartMsg(&uqi,0x15,res,msg,4);//還沒完成
    uartTaskSend(&uqi);
}

static void test_on_ping_success(esp_ping_handle_t hdl, void *args)
{
    // optionally, get callback arguments
    // const char* str = (const char*) args;
    // printf("%s\r\n", str); // "foo"
    uint8_t ttl;
    uint16_t seqno;
    uint32_t elapsed_time, recv_len;
    ip_addr_t target_addr;
    esp_ping_get_profile(hdl, ESP_PING_PROF_SEQNO, &seqno, sizeof(seqno));
    esp_ping_get_profile(hdl, ESP_PING_PROF_TTL, &ttl, sizeof(ttl));
    esp_ping_get_profile(hdl, ESP_PING_PROF_IPADDR, &target_addr, sizeof(target_addr));
    esp_ping_get_profile(hdl, ESP_PING_PROF_SIZE, &recv_len, sizeof(recv_len));
    esp_ping_get_profile(hdl, ESP_PING_PROF_TIMEGAP, &elapsed_time, sizeof(elapsed_time));
    printf("%ld bytes from %s icmp_seq=%d ttl=%d time=%ld ms\n",
           recv_len, inet_ntoa(target_addr.u_addr.ip4), seqno, ttl, elapsed_time);

    sendPingRes(0x00,seqno,elapsed_time);
}

static void test_on_ping_timeout(esp_ping_handle_t hdl, void *args)
{
    uint16_t seqno;
    ip_addr_t target_addr;
    esp_ping_get_profile(hdl, ESP_PING_PROF_SEQNO, &seqno, sizeof(seqno));
    esp_ping_get_profile(hdl, ESP_PING_PROF_IPADDR, &target_addr, sizeof(target_addr));
    printf("From %s icmp_seq=%d timeout\n", inet_ntoa(target_addr.u_addr.ip4), seqno);

    sendPingRes(0x10,seqno,0xffff);
}

static void test_on_ping_end(esp_ping_handle_t hdl, void *args)
{
    uint32_t transmitted;
    uint32_t received;
    uint32_t total_time_ms;

    esp_ping_get_profile(hdl, ESP_PING_PROF_REQUEST, &transmitted, sizeof(transmitted));
    esp_ping_get_profile(hdl, ESP_PING_PROF_REPLY, &received, sizeof(received));
    esp_ping_get_profile(hdl, ESP_PING_PROF_DURATION, &total_time_ms, sizeof(total_time_ms));
    printf("%ld packets transmitted, %ld received, time %ldms\n", transmitted, received, total_time_ms);

    sendPingRes(0x00,0xff,0x00);
}

static void testPing(char* url)
{
    printf("PPPPPPPP A\r\n");

    if(url==0 && isPingStart){
        printf("UUUUUUUUUUUU01\r\n");
        esp_ping_stop(ping);
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        printf("UUUUUUUUUUUU02\r\n");
        esp_ping_delete_session(ping);
        printf("UUUUUUUUUUUU03\r\n");
        return;
    }

    /* convert URL to IP address */
    ip_addr_t target_addr;
    struct addrinfo hint;
    struct addrinfo *res = NULL;
    memset(&hint, 0, sizeof(hint));
    memset(&target_addr, 0, sizeof(target_addr));
    getaddrinfo(url, NULL, &hint, &res);
    struct in_addr addr4 = ((struct sockaddr_in *) (res->ai_addr))->sin_addr;
    inet_addr_to_ip4addr(ip_2_ip4(&target_addr), &addr4);
    freeaddrinfo(res);

    printf("PPPPPPPP B\r\n");

    esp_ping_config_t ping_config = ESP_PING_DEFAULT_CONFIG();
    ping_config.target_addr = target_addr;          // target IP address
    ping_config.count = ESP_PING_COUNT_INFINITE;    // ping in infinite mode, esp_ping_stop can stop it

    /* set callback functions */
    esp_ping_callbacks_t cbs;
    cbs.on_ping_success = test_on_ping_success;
    cbs.on_ping_timeout = test_on_ping_timeout;
    cbs.on_ping_end = test_on_ping_end;
    cbs.cb_args = "foo";  // arguments that feeds to all callback functions, can be NULL

    printf("PPPPPPPP C\r\n");

    esp_ping_new_session(&ping_config, &cbs, &ping);
    esp_ping_start(ping);
    isPingStart=true;

    printf("PPPPPPPPp  ping session created\r\n");
}
//===============================================================================================

static void event_handler(void* arg, esp_event_base_t event_base,
                                int32_t event_id, void* event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        isConnected=false;

        if(reqForceDisconnect){
            ESP_LOGI(TAG, "force disconnect wifi ap");
            reqForceDisconnect=false;
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
            return;
        }

        esp_wifi_connect();
        s_retry_num++;
        if(s_retry_num>WIFI_CONFIG_ESP_MAXIMUM_RETRY){
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
        }
        
    } else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        isConnected=true;

        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        s_retry_num = 0;

    
        currentIp=event->ip_info.ip;
        currentNetmask=event->ip_info.netmask;
        currentGateway=event->ip_info.gw;

        esp_netif_t *netif = event->esp_netif;

        ESP_LOGI(TAG, "WiFi Connected");
        ESP_LOGI(TAG, "~~~~~~~~~~~~~~");
        ESP_LOGI(TAG, "IP          : " IPSTR, IP2STR(&currentIp));
        ESP_LOGI(TAG, "Netmask     : " IPSTR, IP2STR(&currentNetmask));
        ESP_LOGI(TAG, "Gateway     : " IPSTR, IP2STR(&currentGateway));
        esp_netif_get_dns_info(netif, 0, &currentDnsInfo1);
        ESP_LOGI(TAG, "Name Server1: " IPSTR, IP2STR(&currentDnsInfo1.ip.u_addr.ip4));
        esp_netif_get_dns_info(netif, 1, &currentDnsInfo2);
        ESP_LOGI(TAG, "Name Server2: " IPSTR, IP2STR(&currentDnsInfo2.ip.u_addr.ip4));
        ESP_LOGI(TAG, "~~~~~~~~~~~~~~");
        
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

void wifiConfigInit(){
    printf("wifiConfigInit...\r\n");

    s_wifi_event_group = xEventGroupCreate();

    ESP_ERROR_CHECK(esp_netif_init());

    ESP_ERROR_CHECK(esp_event_loop_create_default());
    my_sta=esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT,
                                                        ESP_EVENT_ANY_ID,
                                                        &event_handler,
                                                        NULL,
                                                        &instance_any_id));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(IP_EVENT,
                                                        IP_EVENT_STA_GOT_IP,
                                                        &event_handler,
                                                        NULL,
                                                        &instance_got_ip));  
                                                        
    printf("wifiConfigInit done\r\n");
    //sprintf(wifiSsid,"%s","#21GQ3139ugj0[24");
    //sprintf(wifiPw,"%s","2-JGv801vnpq23jf");
    sprintf(wifiSsid,"%s",CONFIG_SAMPLE_IOT_WIFI_SSID);
    sprintf(wifiPw,"%s",CONFIG_SAMPLE_IOT_WIFI_PASSWORD);
    tryToConnectWifi();
}

//===============================================================================================

bool tryToConnectWifi(){

    if(isConnected){
        reqForceDisconnect=true;
        esp_wifi_disconnect();
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }

    wifi_config_t wifi_config = {
        .sta = {
            //.threshold.authmode = WIFI_AUTH_WPA2_PSK,
            .sae_pwe_h2e = WPA3_SAE_PWE_BOTH,
        },
    };
    memcpy(wifi_config.sta.ssid,wifiSsid,strlen(wifiSsid));
    memcpy(wifi_config.sta.password,wifiPw,strlen(wifiSsid));

    s_retry_num = 0;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA) );
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config) );

    if(hasFixedIpConfig){
        esp_netif_dhcpc_stop(my_sta);
        esp_netif_set_ip_info(my_sta, &fixedIpInfo);
        esp_netif_set_dns_info(my_sta, ESP_NETIF_DNS_MAIN, &fixedDnsInfo1);
        esp_netif_set_dns_info(my_sta, ESP_NETIF_DNS_BACKUP, &fixedDnsInfo2);
    }else{
        esp_netif_dhcpc_start(my_sta);
    }

    xEventGroupClearBits(s_wifi_event_group, WIFI_CONNECTED_BIT | WIFI_FAIL_BIT);

    ESP_ERROR_CHECK(esp_wifi_start() );
    esp_wifi_connect();//第一次呼叫esp_wifi_start會自動connect，之後就不會

    ESP_LOGI(TAG, "wifi_init_sta finished.");

    /* Waiting until either the connection is established (WIFI_CONNECTED_BIT) or connection failed for the maximum
     * number of re-tries (WIFI_FAIL_BIT). The bits are set by event_handler() (see above) */
    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
            WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
            pdFALSE,
            pdFALSE,
            portMAX_DELAY);

    /* xEventGroupWaitBits() returns the bits before the call returned, hence we can test which event actually
     * happened. */
    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG, "connected to ap SSID:%s password:%s",
                 wifiSsid, wifiPw);
        return true;
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGI(TAG, "Failed to connect to SSID:%s, password:%s",
                 wifiSsid, wifiPw);
    } else {
        ESP_LOGE(TAG, "UNEXPECTED EVENT");
    }
    return false;
}


bool wifiConfigCheckMessageType(uint8_t cmd){
    return cmd==0x11 || cmd==0x12 || cmd==0x13 || cmd==0x14 || cmd==0x15;
}
void wifiConfigHandleMessage(uint8_t* msg,int32_t len){
    UART_QUEUE_ITEM uqi;
    uint8_t cmd=msg[0];
    uint8_t* cxt=msg+1;

    printf("get wifi cfg cmd 0x%02x\r\n",cmd);

    switch(cmd){
        case 0x11:{
            //[cmd, ssid_len, wifi_ssid, pw_len, wifi_pw]
            uint8_t ssidLen=*cxt++;
            if(ssidLen+2>len){
                utilPrepareUartMsg(&uqi,0x11,0x10,0,0);
                uartTaskSend(&uqi);
                break;
            }else{
                memcpy(wifiSsid,cxt,ssidLen);
                wifiSsid[ssidLen]=0;
                cxt+=ssidLen;
            }
            uint8_t pwLen=*cxt++;
            if(pwLen+ssidLen+3>len){
                utilPrepareUartMsg(&uqi,0x11,0x10,0,0);
                uartTaskSend(&uqi);
                break;
            }else{
                memcpy(wifiPw,cxt,pwLen);
                wifiPw[pwLen]=0;
            }
            hasFixedIpConfig=false;

            utilPrepareUartMsg(&uqi,0x11,0x00,0,0);
            uartTaskSend(&uqi);
            break;
        }

        case 0x12:{
            //[cmd, ssid_len, wifi_ssid, pw_len, wifi_pw]
            uint8_t ssidLen=*cxt++;
            if(ssidLen+2+20>len){
                utilPrepareUartMsg(&uqi,0x12,0x10,0,0);
                uartTaskSend(&uqi);
                break;
            }else{
                memcpy(wifiSsid,cxt,ssidLen);
                wifiSsid[ssidLen]=0;
                cxt+=ssidLen;
            }
            uint8_t pwLen=*cxt++;
            if(pwLen+ssidLen+3+20>len){
                utilPrepareUartMsg(&uqi,0x12,0x10,0,0);
                uartTaskSend(&uqi);
                break;
            }else{
                memcpy(wifiPw,cxt,pwLen);
                wifiPw[pwLen]=0;
                cxt+=pwLen;
            }

            //需要確認順序
            IP4_ADDR(&fixedIpInfo.ip, cxt[0],cxt[1],cxt[2],cxt[3]);cxt+=4;
            IP4_ADDR(&fixedIpInfo.gw, cxt[0],cxt[1],cxt[2],cxt[3]);cxt+=4;
            IP4_ADDR(&fixedIpInfo.netmask, cxt[0],cxt[1],cxt[2],cxt[3]);cxt+=4;
            IP_ADDR4(&fixedDnsInfo1.ip, cxt[0],cxt[1],cxt[2],cxt[3]);cxt+=4;
            IP_ADDR4(&fixedDnsInfo2.ip, cxt[0],cxt[1],cxt[2],cxt[3]);cxt+=4;
            hasFixedIpConfig=true;

            utilPrepareUartMsg(&uqi,0x12,0x00,0,0);
            uartTaskSend(&uqi);
            break;
        }

        case 0x13:{
            bool res=tryToConnectWifi();
            if(res){
                utilPrepareUartMsg(&uqi,0x13,0x00,0,0);
            }else{
                utilPrepareUartMsg(&uqi,0x13,0x10,0,0);
            }
            uartTaskSend(&uqi);
            break;
        }

        case 0x14:{
            if(isConnected==false){
                utilPrepareUartMsg(&uqi,0x14,0x10,0,0);
                uartTaskSend(&uqi);
                return;
            }else{
                uint8_t* tmpBuf=(uint8_t*)malloc(20);

                utilUint32ToLsbBytes(tmpBuf,currentIp.addr);
                utilUint32ToLsbBytes(tmpBuf+4,currentNetmask.addr);
                utilUint32ToLsbBytes(tmpBuf+8,currentGateway.addr);
                utilUint32ToLsbBytes(tmpBuf+12,currentDnsInfo1.ip.u_addr.ip4.addr);
                utilUint32ToLsbBytes(tmpBuf+16,currentDnsInfo2.ip.u_addr.ip4.addr);

                utilPrepareUartMsg(&uqi,0x14,0x00,tmpBuf,20);
                uartTaskSend(&uqi);

                free(tmpBuf);
            }

            break;
        }

        case 0x15:{
            
            if(len-1==0){
                printf("PPPPPPPPPPPPP stop\r\n");
                testPing(0);
            }else{
                char* url=(char*)cxt;
                url[len-1]=0;

                printf("PPPPPPPPPPPPP start %s\r\n",url);
                testPing(url);
            }
            

            utilPrepareUartMsg(&uqi,0x15,0x00,0,0);//還沒完成
            uartTaskSend(&uqi);
            break;
        }

    }
}