#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_log.h"

#include "global.h"
#include "uart_task.h"

#define TAG "UART"

#define TXD_PIN (GPIO_NUM_17)
#define RXD_PIN (GPIO_NUM_16)
#define UART_BUF_SIZE   2048
//===================================================================================

typedef struct{
	uint8_t buf[UART_BUF_SIZE];
	int32_t	idx;
	int32_t len;
	bool reqNextByte;
	bool getHeader;
}UART_DEC_INFO;

static TaskHandle_t uartTxHandler = NULL;
static TaskHandle_t uartRxHandler = NULL;

static UART_DEC_INFO decInfo;
static QueueHandle_t uartTxQueue;

static void resetUartDecInfo(UART_DEC_INFO* udi){
	udi->idx=0;
	udi->len=0;
	udi->reqNextByte=false;
    udi->getHeader=false;
	//memset(udi->buf,0,UART_BUF_SIZE);
}

static uint8_t* byteEncode(uint8_t src, uint8_t* dst){
	switch(src){
		case 0xA0:
			*dst++=0xA0;
			*dst++=0x01;
			break;
		
		case 0xA1:
			*dst++=0xA0;
			*dst++=0x02;
			break;

		case 0xAF:
			*dst++=0xA0;
			*dst++=0x03;
			break;

		default:
			*dst++=src;
			break;
	}
	return dst;
}

static int32_t uartEncode(uint8_t* src,int32_t len,uint8_t*dst){
	uint8_t* bkDst=dst;

	*dst++=0xA1;//header
	dst=byteEncode((len>>8)&0x00ff,dst);
	dst=byteEncode((len)&0x00ff,dst);
	uint8_t cs=0;
	for(int i=0;i<len;i++){
		uint8_t val=*src++;
		dst=byteEncode(val,dst);
		cs+=val;
	}
	dst=byteEncode(cs,dst);
	*dst++=0xAF;//footer

	return dst-bkDst;
}

static bool uartDecode(uint8_t data,UART_DEC_INFO* udi){
	if(udi->reqNextByte){
		switch(data){
			case 1:
				data=0xA0;
				break;
			case 2:
				data=0xA1;
				break;
			case 3:
				data=0xAF;
				break;
			default:
				resetUartDecInfo(udi);
				return false;
		}
		udi->buf[udi->idx++]=data;
		udi->reqNextByte=false;
	}else if(udi->getHeader==false){
		if(data==0xA1){
			udi->getHeader=true;
            udi->reqNextByte=false;
			udi->idx=0;
			udi->len=0;
		}
	}else{
		switch(data){
			case 0xA0:
				udi->reqNextByte=true;
				break;

			case 0xA1://通常是哪邊出錯，重置udi
				resetUartDecInfo(udi);
				udi->getHeader=true;
				break;

			case 0xAF:
				udi->len=udi->idx;
				udi->idx=0;
				udi->getHeader=false;
                udi->reqNextByte=false;//照理說此時reqNextByte不該為true
				return true;

			default:
				udi->buf[udi->idx++]=data;
				if(udi->idx>=UART_BUF_SIZE){//通常是哪邊出錯，重置udi
					resetUartDecInfo(udi);
				}
				break;
		}
	}
	return false;
}

//===================================================================================

static void initUart(){
	//init uart
    const uart_config_t uart_config = {
        .baud_rate = 230400,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    // We won't use a buffer for sending data.
    uart_driver_install(UART_NUM_1, 512 * 2, 0, 0, NULL, 0);
    uart_param_config(UART_NUM_1, &uart_config);
    uart_set_pin(UART_NUM_1, TXD_PIN, RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
}

static int preFhs=0;
static void printHeapInfo(){
    int fhs=esp_get_free_heap_size();
    if(preFhs==0){
        preFhs=fhs;
    }else if(preFhs!=fhs){
        ESP_LOGI(TAG, "free heap size: %d pre: %d diff: %d",fhs,preFhs,fhs-preFhs);
		preFhs=fhs;
    }
}

static void uartTxTask(void *arg)
{
	UART_QUEUE_ITEM uqi;
	uint8_t* encData=(uint8_t*)malloc(UART_BUF_SIZE*2);

    while (1) {
		//檢查ota task有無處理結果
		if (xQueueReceive(uartTxQueue, (void *)&uqi,1000) == pdTRUE){
			uint8_t* raw=uqi.buf;
			int32_t len=uqi.len;
			int32_t encLen=uartEncode(raw,len,encData);
            //編碼後必須將記憶體釋放

			printf("get buf ptr: %p, len:%ld, encLen:%ld\r\n",raw,len,encLen);
            free(raw);
			uart_write_bytes(UART_NUM_1, encData, encLen);
			//uart_wait_tx_done(UART_NUM_1, 100);
		}

        printHeapInfo();
    }
}

static void uartRxTask(void * param){
	uint8_t* data = (uint8_t*) malloc(512);
	UART_QUEUE_ITEM uqi;
    resetUartDecInfo(&decInfo);

	while(1){
		// printf("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
		const int byteCnt = uart_read_bytes(UART_NUM_1, data, 512, 100 / portTICK_PERIOD_MS);

		for(int i=0;i<byteCnt;i++){
			
			
			bool res=uartDecode(data[i],&decInfo);
			if(res){
				//檢查checksum與size

				int32_t len=decInfo.buf[0];
				len<<=8;
				len+=decInfo.buf[1];

				if(len!=decInfo.len-3){//-3是因為len與cs共3byte；長度比對不同，傳送錯誤給stm32
					uqi.buf=(uint8_t*)malloc(2);
					uqi.len=2;
					uqi.buf[0]=0xff;
					uqi.buf[1]=0x01;
					uartTaskSend(&uqi);
					continue;
				}

				//printf("%02x %02x %02x %02x\r\n",decInfo.buf[0],decInfo.buf[1],decInfo.buf[2],decInfo.buf[3]);

				uint32_t cs=0;
				for(int i=0;i<len;i++){
					cs+=decInfo.buf[2+i];
				}
				cs&=0x00ff;
				if(cs!=decInfo.buf[decInfo.len-1]){//cs比對不同，傳送錯誤給stm32
					uqi.buf=(uint8_t*)malloc(2);
					uqi.len=2;
					uqi.buf[0]=0xff;
					uqi.buf[1]=0x02;
                    uartTaskSend(&uqi);

					printf("cs err %02lx %02x\r\n",cs,decInfo.buf[decInfo.len-1]);
					continue;
				}

                uartTaskMessageCallback(decInfo.buf+2,len);
                resetUartDecInfo(&decInfo);
			}
		}
	}
}

//=============================================================================

void uartTaskInit(){
    initUart();
    uartTxQueue = xQueueCreate(10, sizeof(UART_QUEUE_ITEM));
}
void uartTaskStart(){
	xTaskCreatePinnedToCore( uartTxTask, "utx", 8192, NULL, tskIDLE_PRIORITY+2, &uartTxHandler ,1);
	xTaskCreatePinnedToCore( uartRxTask, "urx", 8192, NULL, tskIDLE_PRIORITY+2, &uartRxHandler ,1);
}
void uartTaskSend(UART_QUEUE_ITEM* uqi){
    xQueueSend(uartTxQueue, (void *)uqi,portMAX_DELAY);
}

