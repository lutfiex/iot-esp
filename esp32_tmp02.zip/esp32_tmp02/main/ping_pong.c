#include <string.h>
#include "global.h"
#include "ping_pong.h"
#include "util.h"
#include "uart_task.h"

bool pingPongCheckMessageType(uint8_t type){
    return type==0x01;
}
void pingPongHandleMessage(uint8_t* msg,int32_t len){
    UART_QUEUE_ITEM uqi;

    if(msg[0]==0x01 && len==5 && memcmp(msg+1,"ping",4)==0){
        utilPrepareUartMsg(&uqi,0x01,0x00,(const uint8_t*)"pong",4);
    }else{
        utilPrepareUartMsg(&uqi,0x01,0x10,0,0);
    }
    uartTaskSend(&uqi);
}