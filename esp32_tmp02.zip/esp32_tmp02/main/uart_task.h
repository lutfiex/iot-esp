#ifndef __JD_UART_TASK_H__
#define __JD_UART_TASK_H__

#include "global.h"

void uartTaskInit();
void uartTaskStart();
void uartTaskSend(UART_QUEUE_ITEM* uqi);

extern void uartTaskMessageCallback(uint8_t* msg,int32_t len);

#endif