#ifndef __JD_WIFI_CONFIG_H__
#define __JD_WIFI_CONFIG_H__

#include <stdint.h>
#include <stdbool.h>

void wifiConfigInit();
bool wifiConfigCheckMessageType(uint8_t type);
void wifiConfigHandleMessage(uint8_t* msg,int32_t len);

bool wifiConfigIsConnected();

#endif