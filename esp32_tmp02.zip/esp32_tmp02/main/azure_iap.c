#include <string.h>
#include "global.h"
#include "azure_iap.h"
#include "util.h"
#include "uart_task.h"
#include "azure_state_load_file.h"
#include <global_var.h>
#include "flash_fatfs.h"
#include "esp_vfs_fat.h"
#include "esp_ota_ops.h"
#include "driver/gpio.h"


#include "azure_sample_connection.h"
#define disconnect 0
#define connect 1
extern bool gate;
extern bool isConnected; 
extern LoadFileState espLoadFileState;
extern int32_t loadFileGetCurrentStatus(char* fn,int32_t* currLen,int32_t* totalLen);

bool azureIapCheckMessageType(uint8_t type){
    if(type==0x31 || type==0x32 ||type==0x33 ||type==0x34 ||type==0x35 ||type==0x3f || type==0x40){
        return true;
    }
    return false;
}

extern int32_t azureState;

static void checkAzureState(){
    UART_QUEUE_ITEM uqi;
    int32_t len=2;
    uint8_t* txMsg=(uint8_t*)malloc(len);

    txMsg[0]=0x31;
    if(azureState==0){
        txMsg[1]=0;
    }else{
        txMsg[1]=0x10;
    }

    uqi.buf=txMsg;
    uqi.len=len;
    uartTaskSend(&uqi);
}

void sendAzureIapMsgToStm32(int32_t cmd,char* fid,uint8_t res,uint8_t* data,int32_t dataLen){
	int32_t fidLen=strlen(fid);

	UART_QUEUE_ITEM uqi;
	int32_t len=3+fidLen+dataLen;
	uint8_t* txMsg=(uint8_t*)malloc(len);
    uint8_t* txMsgBk=txMsg;
	*txMsg++=cmd & 0xff;
	*txMsg++=res;
	*txMsg++=fidLen & 0xff;
	memcpy(txMsg,fid,fidLen);
	txMsg+=fidLen;
    if(dataLen>0){
        memcpy(txMsg,data,dataLen);
    }

	uqi.buf=txMsgBk;
	uqi.len=len;
	uartTaskSend(&uqi);
}

static void updateFile(uint8_t* rxMsg,int32_t msgLen){
    uint8_t fileIdLen=rxMsg[0];

    char fid[256];
    memcpy(fid,rxMsg+1,fileIdLen);
    fid[fileIdLen]=0;

    //startLoadFile("esp",0x0100);
    bool res=startUpdateFile(fid);


    uint8_t response=0;
    if(res){
        response=0;
    }else{
        response=0x10;
    }

    uint8_t progress=0;
    sendAzureIapMsgToStm32(0x32,fid,response,&progress,1);
}

extern const char* verInfoFn;
static void getFileState(uint8_t* rxMsg,int32_t msgLen){
    uint8_t fileIdLen=rxMsg[0];

    char fid[32];
    memcpy(fid,rxMsg+1,fileIdLen);
    fid[fileIdLen]=0;


    int32_t ver=0;
    int32_t size=0;
    uint8_t md5[16];
    uint8_t hasFile=false;
    uint8_t isDownloadIng=0;

    if(espLoadFileState.state>=0){
        if(strcmp(espLoadFileState.fileId,fid)==0){
            isDownloadIng=1;
            size=espLoadFileState.maxSize;
            ver=espLoadFileState.azureVer;
            memcpy(md5,espLoadFileState.md5,16);
        }
    }
    
    if(isDownloadIng==0){
        hasFile=readLocalFileInfo(fid,&ver,&size,md5);

        if(hasFile==false){
            sendAzureIapMsgToStm32(0x33,fid,0x10,0,0);
            return;
        }
    }

    uint8_t cxt[7+16];
    cxt[0]=isDownloadIng?1:0;
    utilUint16ToMsbBytes(cxt+1,ver);
    utilUint32ToMsbBytes(cxt+3,size);
    memcpy(cxt+7,md5,16);
    //printf("cxt size: %d\r\n",sizeof(cxt));
    //printf("md5 %02x %02x %02x %02x\r\n",md5[0],md5[1],md5[2],md5[3]);
    sendAzureIapMsgToStm32(0x33,fid,0,cxt,sizeof(cxt));
}

void sendFilePiece(uint8_t* rxMsg,int32_t msgLen){
    uint8_t fileIdLen=rxMsg[0];
    char fid[32];
    memcpy(fid,rxMsg+1,fileIdLen);
    fid[fileIdLen]=0;

    uint32_t addr=utilMsbBytesToUint32(rxMsg+fileIdLen+1);
    uint32_t size=utilMsbBytesToUint32(rxMsg+fileIdLen+5);
    if(size>1024){
        size=1024;
    }

    printf("sendFilePiece: %ld %ld\r\n",addr,size);

    int32_t ver=0;
    int32_t fileSize=0;
    uint8_t hasFile=false;
    uint8_t isDownloadIng=0;

    if(espLoadFileState.state>=0){
        if(strcmp(espLoadFileState.fileId,fid)==0){
            isDownloadIng=1;
            sendAzureIapMsgToStm32(0x34,fid,0x11,0,0);//下載中，不能讀檔
            return;
        }
    }
    
    if(isDownloadIng==0){
        hasFile=readLocalFileInfo(fid,&ver,&fileSize,0);
        printf("readLocalFileInfo res: %d %ld %ld\r\n",hasFile,ver,fileSize);
    }

    if(hasFile==false){//沒有檔案資訊
        sendAzureIapMsgToStm32(0x34,fid,0x10,0,0);
        return;
    }

    if(fileSize<addr+size){//超出範圍
        sendAzureIapMsgToStm32(0x34,fid,0x12,0,0);
        return;
    }

    int32_t cxtLen=size+9;
    uint8_t* cxt=(uint8_t*)malloc(cxtLen);

    char localFileName[64];
    buildFlashFileNameFromFileId(fid,localFileName);

    //讀取檔案
    FILE *f = fopen(localFileName, "rb");
    fseek(f,addr,SEEK_SET);
    size=fread(cxt+9,1,size,f);
    fclose(f);

    //計算check sum
    uint8_t cs=0;
    uint8_t* ptr=cxt+9;
    for(int32_t i=0;i<size;i++){
        cs+=*ptr++;
    }

    //輸出
    utilUint32ToMsbBytes(cxt,addr);
    utilUint32ToMsbBytes(cxt+4,size);
    cxt[8]=cs;
    sendAzureIapMsgToStm32(0x34,fid,0,cxt,cxtLen);

    free(cxt);
}

static void removeFile(uint8_t* rxMsg,int32_t msgLen){
    uint8_t fileIdLen=rxMsg[0];

    char fid[32];
    memcpy(fid,rxMsg+1,fileIdLen);
    fid[fileIdLen]=0;

    printf("removeFile: %s\r\n",fid);

    removeLocalFileInfo(fid);
    sendAzureIapMsgToStm32(0x35,fid,0,0,0);
}



static void updateEsp32(uint8_t* rxMsg,int32_t msgLen){
    uint8_t fileIdLen=rxMsg[0];

    char fid[32];
    memcpy(fid,rxMsg+1,fileIdLen);
    fid[fileIdLen]=0;

    int32_t ver=0;
    int32_t fileSize=0;
    uint8_t md5[16];
    uint8_t hasFile=false;

    hasFile=readLocalFileInfo(fid,&ver,&fileSize,md5);
    printf("updateEsp32 file info: %d %ld %ld\r\n",hasFile,ver,fileSize);

    if(hasFile==false){
        sendAzureIapMsgToStm32(0x3f,fid,0x11,0,0);
        return;
    }

	const esp_partition_t *updatePart;
    esp_ota_handle_t otaHandle;

    updatePart = esp_ota_get_next_update_partition(NULL);
    esp_err_t err = esp_ota_begin(updatePart, OTA_WITH_SEQUENTIAL_WRITES, &otaHandle);

    if(err != ESP_OK){
        sendAzureIapMsgToStm32(0x3f,fid,0x13,0,0);
        return;
    }

    char localFileName[64];
    buildFlashFileNameFromFileId(fid,localFileName);
    //讀取檔案
    FILE *f = fopen(localFileName, "rb");

    int32_t maxPkgSize=1024;
    int32_t remainSize=fileSize;
    uint32_t writeAddr=0;
    uint8_t* fwBytes=(uint8_t*)malloc(maxPkgSize);
    
    uint8_t progress=0;
    int32_t progressSkipCnt=0;

    while(true){
        if(remainSize==0){
            break;
        }

        int32_t pkgSize=remainSize;
        if(pkgSize>maxPkgSize){
            pkgSize=maxPkgSize;
        }

        int32_t readCnt=fread(fwBytes,1,pkgSize,f);
        
        if(readCnt==0){
            printf("read fw: %p %p %ld %ld\r\n",f,fwBytes,pkgSize,readCnt);
            free(fwBytes);
            fclose(f);
            sendAzureIapMsgToStm32(0x3f,fid,0x12,0,0);
            return;
        }

        err=esp_ota_write(otaHandle, fwBytes, pkgSize);

        if(err != ESP_OK){
            printf("read fw: %p %p %ld %ld\r\n",f,fwBytes,pkgSize,readCnt);
            free(fwBytes);
            fclose(f);
            sendAzureIapMsgToStm32(0x3f,fid,0x14,0,0);
            return;
        }

        writeAddr+=pkgSize;
        remainSize-=pkgSize;

        progressSkipCnt++;
        if(progressSkipCnt>64){
            progressSkipCnt=0;

            progress=writeAddr*100/fileSize;
            sendAzureIapMsgToStm32(0x3f,fid,0,&progress,1);
        }
    }

    progress=100;
    sendAzureIapMsgToStm32(0x3f,fid,0,&progress,1);

    free(fwBytes);
    fclose(f);

    err = esp_ota_end(otaHandle);
    if(err != ESP_OK){
        esp_ota_abort(otaHandle);
        sendAzureIapMsgToStm32(0x3f,fid,0x15,0,0);
        return;
    }

    err = esp_ota_set_boot_partition(updatePart);
    if(err != ESP_OK){
        sendAzureIapMsgToStm32(0x3f,fid,0x16,0,0);
        return;
    } 

    esp_restart();
}

void azure_en(uint8_t* rxMsg,int32_t msgLen){
    
            UART_QUEUE_ITEM uqi;
            int32_t len=4;
            uint8_t* txMsg=(uint8_t*)malloc(len);
            uint8_t otaRes[16];
            memcpy(otaRes,rxMsg,2);
            txMsg[0]=0x40;
            if(otaRes[0] == 0x00 || otaRes[0] == 0x01)
            {
                txMsg[1]=0x00;
                printf("mmmmmmmmmmmmmm");
            }
            else{
                txMsg[1]=0x10;
            }
            printf("aqqqqqqqqqqqqqqqqqqqqqt\r\n");
            printf("%d\r\n",txMsg[0]);
            printf("ssssssssssssssssssssssssssssss %d\r\n",otaRes[0]);

           if(otaRes[0] == 0x00){ // connecting 
				connection_azure = 1;
                printf("azure cmd %d\r\n",connection_azure);
                if(azure_connection_status != 1){
                    if(isConnected){
                        void prvAzureDemoTask();
                        gate = true;
                        while(gate ==true && azure_connection_status == 0)
                        {printf("hahahhahahahahahhahah");
                        vTaskDelay(50);}
                        gate = true;
                        txMsg[3] = azure_connection_status; //connected
                        printf("azure disconnect %d\r\n",txMsg[1]);
                    }
                    else if(!isConnected){
                    txMsg[2] = 0x02; //faild because connection
                    txMsg[3] = azure_connection_status; //connected
                    }
                }
                else{
                    printf("azure_connection_status %d\r\n",azure_connection_status);
                    txMsg[3] = azure_connection_status; //connected
                    printf("azure connect\r\n");
                }
                
                if(azure_connection_status == 0x01 && isConnected){
                    txMsg[2] = 0x01; //success
                }
                else if (!isConnected)
                {
                    connection_azure =0;
                    azure_connection_status = 0;
                    txMsg[2] = 0x02; //faild because connection
                    txMsg[3] = azure_connection_status;
                }
                else{
                    // connection_azure =0;
                     txMsg[2] = 0x10; //faild 
                     
                }
                
				
			}
			else if(otaRes[0] == 0x01){
				connection_azure = 0;
                void prvAzureDemoTask();
                gate = true;
                while(gate == true ){vTaskDelay(100);}
                gate = true;
                if(azure_connection_status == disconnect){
                    txMsg[2] = 0x00; //sucess
                }
				txMsg[3] = azure_connection_status;
                printf("%d",txMsg[1]);
				printf("azure disconnect ssssssssssssssss\r\n");
			}
            else{
                txMsg[2] = 0x10; //faild 
                txMsg[3] = 0x00; 
            }


            if ( txMsg[3]  == 3){
                printf("jijijijijijiji%d/r/n",azure_connection_status);
                vTaskDelay(500);
                azure_en(rxMsg,len);
                }
            // printf("aaaaaaa0 %d\r\n", txMsg[0]);
            // printf("aaaaaaa1 %d\r\n", txMsg[1]);
            
				uqi.buf=txMsg;
                uqi.len = len;
				memcpy(uqi.buf,txMsg,len);
				uartTaskSend(&uqi);
}

void azureIapHandleMessage(uint8_t* msg,int32_t len){
    uint8_t cmd=msg[0];

    switch(cmd){
        case 0x31:{
            checkAzureState();
        }break;

        case 0x32:{
            updateFile(msg+1,len-1);
        }break;

        case 0x33:{
            getFileState(msg+1,len-1);
        }break;

        case 0x34:{
            sendFilePiece(msg+1,len-1);
        }break;

        case 0x35:{
            removeFile(msg+1,len-1);
        }break;

        case 0x3f:{
            updateEsp32(msg+1,len-1);
        }break;
        case 0x40:{
            // gpio_set_level(GPIO_NUM_0,1);
            printf("sadadwwdwdwdwdwdw");
            azure_en(msg+1,len-1);
            // gpio_set_level(GPIO_NUM_0,0);

        }
    }
    
}