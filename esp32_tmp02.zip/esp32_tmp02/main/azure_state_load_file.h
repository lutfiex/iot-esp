#ifndef __AZURE_STATE_LOAD_ESP_FW__
#define __AZURE_STATE_LOAD_ESP_FW__

#include "azure_iot_hub_client.h"
#include <stdbool.h>
#include <cJSON.h>

void initLoadFileProcess();
bool handleLoadFileResponse(char* cmd,AzureIoTHubClient_t* xAzureIoTHubClient,cJSON *root,const uint8_t* bin,uint32_t binSize);
void handleLoadFileStateFun(AzureIoTHubClient_t* xAzureIoTHubClient);

bool startUpdateFile(const char* fileId);
bool startLoadFile(const char* fileId,uint32_t ver);

//output state
int32_t loadFileGetCurrentStatus(char* fn,int32_t* currLen,int32_t* totalLen);
bool readLocalFileInfo(const char* fileId,int32_t* ver, int32_t* size,uint8_t* md5);
bool removeLocalFileInfo(const char* fileId);

#endif