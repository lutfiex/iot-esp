#ifndef __AZURE_GLOBAL_VAR_
#define __AZURE_GLOBAL_VAR_

#include "azure_iot_hub_client.h"
#include "md5.h"
#include <stdint.h>

#define sampleazureiotMESSAGE_CONTENT_TYPE                    "application%2Foctet-stream"
#define sampleazureiotMESSAGE_CONTENT_ENCODING                "us-ascii"

#define ESP32_FW_VER	0x1234



typedef struct{
	int32_t state;
	int32_t idleCnt;
	uint32_t azureVer;
	uint32_t localVer;
	uint32_t currAddr;
	uint32_t maxSize;
	uint8_t md5[16];
	char fileId[32];
	MD5_CTX md5Ctx;
}LoadFileState;

void initLoadFileState(LoadFileState* fs);

extern AzureIoTMessageProperties_t xPropertyBag;
extern AzureIoTResult_t xResult;
extern uint8_t ucPropertyBuffer[ 80 ];
extern uint8_t ucScratchBuffer[ 128 ];
extern uint8_t sample_version ;
extern uint8_t version ;
extern uint32_t read_data ;
extern bool connection_azure;
#endif