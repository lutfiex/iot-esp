#include <cJSON.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "esp_log.h"
#include "azure_comm_cmd.h"
#include "global_var.h"

static const char * TAG = "common_cmd";

bool checkAzureFileVer(const char* fileId,uint32_t ver,AzureIoTHubClient_t* xAzureIoTHubClient){
	char* jsonResPtr=(char*)ucScratchBuffer+2;
	
	cJSON *root = cJSON_CreateObject();
	cJSON_AddStringToObject(root, "cmd", AZURE_CMD_CHECK_VER);
	cJSON_AddStringToObject(root, "file_id", fileId);
	cJSON_AddNumberToObject(root, "cur_ver", ver);
	cJSON_PrintPreallocated(root,jsonResPtr,sizeof( ucScratchBuffer )-2,1);
	uint32_t msgLen=strlen(jsonResPtr);
	cJSON_Delete(root);
	
	ucScratchBuffer[0]=(msgLen>>8)&0x00ff;
	ucScratchBuffer[1]=(msgLen)&0x00ff;
	msgLen+=2;
	
	ESP_LOGI( TAG, "check fw %s cur ver: %lu\r\n",fileId,ver);
	
	AzureIoTResult_t xResult = AzureIoTHubClient_SendTelemetry( xAzureIoTHubClient,
											   ucScratchBuffer, msgLen,
											   &xPropertyBag, eAzureIoTHubMessageQoS1, NULL );
	return xResult == eAzureIoTSuccess;
}

bool checkAzureGetFile(const char* fileId,uint32_t addr,uint32_t size,AzureIoTHubClient_t* xAzureIoTHubClient){
	char* jsonResPtr=(char*)ucScratchBuffer+2;
	
	cJSON *root = cJSON_CreateObject();
	cJSON_AddStringToObject(root, "cmd", AZURE_CMD_GET_FILE);
	cJSON_AddStringToObject(root, "file_id", fileId);
	cJSON_AddNumberToObject(root, "addr", addr);
	cJSON_AddNumberToObject(root, "size", size);
	cJSON_PrintPreallocated(root,jsonResPtr,sizeof( ucScratchBuffer )-2,1);
	uint32_t msgLen=strlen(jsonResPtr);
	cJSON_Delete(root);
	
	ucScratchBuffer[0]=(msgLen>>8)&0x00ff;
	ucScratchBuffer[1]=(msgLen)&0x00ff;
	msgLen+=2;
	
	ESP_LOGI( TAG, "get file addr: %08lx size:%lu \r\n",addr,size);
	
	AzureIoTResult_t xResult = AzureIoTHubClient_SendTelemetry( xAzureIoTHubClient,
											   ucScratchBuffer, msgLen,
											   &xPropertyBag, eAzureIoTHubMessageQoS1, NULL );
	return xResult == eAzureIoTSuccess;
}

static uint8_t convetHalfHex(const char c){
	if(c>='0' && c<='9'){
		return c-'0';
	}
	if(c>='a' && c<='f'){
		return c-'a'+10;
	}
	if(c>='A' && c<='F'){
		return c-'A'+10;
	}
	return 0;
} 
int32_t convertHexToBytes(const char* hex,int32_t hexLen,uint8_t* res){
	int32_t byteCnt=hexLen/2;
	
	for(int32_t i=0;i<byteCnt;i++){
		uint8_t b = convetHalfHex(*hex++);
		b <<= 4;
		b |= convetHalfHex(*hex++);
		*res++=b;
	}
	return byteCnt;
}