#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "md5.h"

#include "esp_ota_ops.h"
#include "nvs.h"
#include "nvs_flash.h"
#include "esp_log.h"

#include "global.h"
#include "util.h"
#include "iap_task.h"
#include "uart_task.h"

#include "azure_sample_connection.h"

#define TAG "IAP"

#define FLASH_WRITE_SIZE	2048
#define STM_UART_BUF_SIZE	(FLASH_WRITE_SIZE+256)

#include "global_var.h"

typedef struct{
	esp_ota_handle_t otaHandle;
	const esp_partition_t *updatePart;
	const esp_partition_t *cfgPart;
	const esp_partition_t *runPart;
}IAP_STATE;

IAP_STATE iapState;
bool isIapInited=false;
MD5_CTX md5Ctx;
QueueHandle_t iapPkgNotifyQueue;

static uint8_t iapBuf[STM_UART_BUF_SIZE];
static uint32_t fwSize=0;
static uint32_t currPartAddress;
static uint32_t currPartSize=0;

static TaskHandle_t iapHandler = NULL;

//=============================================================================

static bool ipaInit(uint32_t size){
	MD5Init(&md5Ctx);
	
	if(isIapInited){
		return true;
	}isIapInited=true;
	
	iapState.cfgPart=esp_ota_get_boot_partition();
	iapState.runPart=esp_ota_get_running_partition();

	if (iapState.cfgPart != iapState.runPart) {
        ESP_LOGW(TAG, "Configured OTA boot partition at offset 0x%08x, but running from offset 0x%08x",
                 (int)iapState.cfgPart->address, (int)iapState.runPart->address);
        ESP_LOGW(TAG, "(This can happen if either the OTA boot data or preferred boot image become corrupted somehow.)");
    }
    ESP_LOGI(TAG, "Running partition type %d subtype %d (offset 0x%08x)",
             iapState.runPart->type, iapState.runPart->subtype, (int)iapState.runPart->address);
			 
	iapState.updatePart = esp_ota_get_next_update_partition(NULL);
    ESP_LOGI(TAG, "Writing to partition subtype %d at offset 0x%x",
             iapState.updatePart->subtype, (int)iapState.updatePart->address);
    if(iapState.updatePart == NULL){
		return false;
	}
	
	//esp_err_t err = esp_ota_begin(iapState.updatePart, size, &(iapState.otaHandle));
	//搭配esp_ota_write_with_offset
	
	esp_err_t err = esp_ota_begin(iapState.updatePart, OTA_WITH_SEQUENTIAL_WRITES, &(iapState.otaHandle));
	//搭配esp_ota_write

	
	if (err != ESP_OK) {
		ESP_LOGE(TAG, "esp_ota_begin failed (%s)", esp_err_to_name(err));
		esp_ota_abort(iapState.otaHandle);
		return false;
	}

	ESP_LOGI(TAG, "esp_ota_begin succeeded");
	return true;
}

static bool ipaFinish(uint8_t* md5Ref){
	uint8_t md5[16];
	MD5Final(md5,&md5Ctx);
	
	int32_t cmpRes=memcmp(md5,md5Ref,16);
	if(cmpRes!=0){
		char errStr[128];
		char* ptr=errStr;
		for(int32_t i=0;i<16;i++){
			ptr+=sprintf(ptr,"%02x ",md5[i]);
		}sprintf(ptr,"\r\n");
		printf(errStr);
		
		ptr=errStr;
		for(int32_t i=0;i<16;i++){
			ptr+=sprintf(ptr,"%02x ",md5Ref[i]);
		}sprintf(ptr,"\r\n");
		printf(errStr);
		
		esp_ota_abort(iapState.otaHandle);
		isIapInited=false;
		return false;
	}
	
    esp_err_t err = esp_ota_end(iapState.otaHandle);
    if (err != ESP_OK) {
        if (err == ESP_ERR_OTA_VALIDATE_FAILED) {
            ESP_LOGE(TAG, "Image validation failed, image is corrupted");
        }
        ESP_LOGE(TAG, "esp_ota_end failed (%s)!", esp_err_to_name(err));
		esp_ota_abort(iapState.otaHandle);
		isIapInited=false;
		return false;
    }
	
	isIapInited=false;
	//esptool.py -p COM3 -b 921600 read_flash 0x00110000 184736  flash_dump.bin
	return true;
}

static bool ipaSwitch(){
    esp_err_t err = esp_ota_set_boot_partition(iapState.updatePart);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "esp_ota_set_boot_partition failed (%s)!", esp_err_to_name(err));
		return false;
    }
	esp_restart();
	
	return true;
}

static bool ipaWriteFlash(uint32_t offset,uint8_t* buf,uint32_t size){
	MD5Update(&md5Ctx,buf,size);
	
	if(size<FLASH_WRITE_SIZE){
		memset(buf+size,0xff,FLASH_WRITE_SIZE-size);
	}
	//esp_err_t err=esp_ota_write_with_offset(iapState.otaHandle, buf, size,offset);
	esp_err_t err=esp_ota_write(iapState.otaHandle, buf, size);
	
	if (err != ESP_OK) {
		ESP_LOGE(TAG, "esp_ota_write fail");
		esp_ota_abort(iapState.otaHandle);
		return false;
	}
	return true;
}

//=============================================================================

static int otaMsgHandller(uint8_t* rxBuf,uint8_t* txBuf,uint32_t size){
	//[cmd: 1 byte][params]
	//begin ota [0x81][total size: uint32_t, msb]
	//part      [0x82][part data cnt: uint32_t, msb][part addr: uint32_t, msb][uint8_t checksum][data: (part data cnt) bytes]
	//end ota   [0x83][md5: 16bytes]
	bool success=false;
	
	printf("cmd: %02x %02x %02x %02x %02x\r\n",rxBuf[0],rxBuf[1],rxBuf[2],rxBuf[3],rxBuf[4]);
	
	switch(rxBuf[0]){
		case 0x81:{
			if(size<5){
				txBuf[0]=0x81;
				txBuf[1]=0x12;//長度不足
				return 2;
			}
			fwSize=utilMsbBytesToUint32(rxBuf+1);
			
			success=ipaInit(fwSize);
			txBuf[0]=0x81;
			printf("%d\r\n",success);
			if(success){
				txBuf[1]=0x00;
				utilUint32ToMsbBytes(txBuf+2,fwSize);
			}else{
				txBuf[1]=0x10;
			}
			
			printf("begin ota cmd: %ld,%d\r\n",fwSize,success);
			return 2;
		}
		
		case 0x82:{
			if(size<10){
				txBuf[0]=0x82;
				txBuf[1]=0x12;//長度不足
				return 2;
			}
			currPartAddress=utilMsbBytesToUint32(rxBuf+1);
			currPartSize=utilMsbBytesToUint32(rxBuf+1+4);
			uint32_t checksum=(rxBuf[1+4+4]&0x00ff);
			uint8_t* data=rxBuf+1+4+4+1;
			uint32_t tmp=0;
			for(int32_t i=0;i<currPartSize;i++){
				tmp += data[i];
			}
			
			tmp&=0x00ff;
			success=(tmp == checksum);

			if(success){
				success=ipaWriteFlash(currPartAddress,data,currPartSize);
				if(success){
					txBuf[1]=0x00;
					//utilUint32ToMsbBytes(txBuf+2,currPartAddress);
					//utilUint32ToMsbBytes(txBuf+2+4,currPartSize);
				}else{
					txBuf[1]=0x10;
				}
			}else{
				txBuf[1]=0x11;
			}
			
			txBuf[0]=0x82;
			printf("write flash: %08lx, %ld, %04lx, %04lx, %02x\r\n",currPartAddress,currPartSize,tmp,checksum,success);
			return 2;
		}
		
		case 0x83:{
			success=ipaFinish(rxBuf+1);
			
			txBuf[0]=0x83;
			if(success){
				txBuf[1]=0x00;
			}else{
				txBuf[1]=0x10;
			}
			
			printf("check md5: %d\r\n",success);
			return 2;
		}
		
		case 0x84:{
			success=ipaSwitch();
			
			txBuf[0]=0x84;
			if(success){
				txBuf[1]=0x00;
			}else{
				txBuf[1]=0x10;
			}
			
			printf("switch app: %d\r\n",success);
			return 2;
		}
		case 0x00:{
			txBuf[0] = 0x00; //cmd
			txBuf[1] = 0x00; // res
			txBuf[2] = version;
			printf( "version): %d\r\n",version);
			return 3;
		}
		case 0x03:{
			txBuf[0] = 0x03; //cmd
			txBuf[1] = 0x00; //res
			txBuf[2] = sample_version;
			return 3;
		}
		
		case 0x04:{
			txBuf[0] = 0x04;
			txBuf[1] = 0x00;
			txBuf[2] = read_data>>24;
			txBuf[3] = read_data>>16;
			txBuf[4] = read_data>>8;
			txBuf[5] = read_data;
			// printf( "wrtriten data : (0x%" PRIx8 " bytes)\r\n",txBuf[2]);
			printf( "wrtriten data : (0x%" PRIx32 " bytes)\r\n",read_data);
			return 6;
		}
		
		
		case 0xff:{
			//do nothing, master read back result
			return 0;
		}
		
	}
	return 0;
}


static void iapTask(void * param){
	int32_t notify=0;
	UART_QUEUE_ITEM uqi;
	uint8_t otaRes[16];
	
	while(1){
		// printf("LLOLOLOLOLOLOLOLLLOLOL");
		if (xQueueReceive(iapPkgNotifyQueue, (void *)&notify, portMAX_DELAY) == pdTRUE){
			printf("get msg: %ld\r\n",notify);
			memset(otaRes,0,16);
			uint32_t len=otaMsgHandller(iapBuf,otaRes,notify);

			if(len>0){
				uqi.buf=(uint8_t*)malloc(len);
				uqi.len=len;
				memcpy(uqi.buf,otaRes,len);
				uartTaskSend(&uqi);
			}
		}
	}
}


//=============================================================================

void iapTaskInit(){
    iapPkgNotifyQueue = xQueueCreate(1, sizeof(int32_t));
}

bool iapTaskCheckMessageType(uint8_t cmd){
    return cmd==0x81 || cmd==0x82 || cmd==0x83 || cmd==0x84 || cmd==00 || cmd==0x03 || cmd==0x04 ;
}

void iapTaskHandleMessage(uint8_t* msg,int32_t len){
    memcpy(iapBuf,msg,len);
    int32_t notify=len;
    xQueueSend(iapPkgNotifyQueue, (void *)&notify,portMAX_DELAY);
}

void iapTaskStart(){
    xTaskCreatePinnedToCore( iapTask, "iap", 8192, NULL, tskIDLE_PRIORITY+1, &iapHandler ,1);
}
