#ifndef __JD_PING_PONG_H__
#define __JD_PING_PONG_H__

#include <stdint.h>
#include <stdbool.h>

bool pingPongCheckMessageType(uint8_t type);
void pingPongHandleMessage(uint8_t* msg,int32_t len);

#endif