/* Copyright (c) Microsoft Corporation. All rights reserved. */
/* SPDX-License-Identifier: MIT */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "azure_sample_connection.h"

#include "sdkconfig.h"
#include "esp_event.h"
#include "esp_wifi.h"
#include "esp_wifi_default.h"
#include "esp_err.h"
#include "esp_netif.h"
#include "esp_sntp.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "nvs_flash.h"
/*-----------------------------------------------------------*/
#include "global_var.h"
#include "azure_state_load_file.h"
#include "driver/gpio.h"
#include <cJSON.h>
/*-----------------------------------------------------------*/
#define GPIO_OUTPUT_IO CONFIG_GPIO_OUTPUT_33
#define GPIO_OUTPUT_PIN_SEL (1ULL<<GPIO_OUTPUT_IO_0)


#define NR_OF_IP_ADDRESSES_TO_WAIT_FOR     1

#if CONFIG_SAMPLE_IOT_WIFI_SCAN_METHOD_FAST
    #define SAMPLE_IOT_WIFI_SCAN_METHOD    WIFI_FAST_SCAN
#elif CONFIG_SAMPLE_IOT_WIFI_SCAN_METHOD_ALL_CHANNEL
    #define SAMPLE_IOT_WIFI_SCAN_METHOD    WIFI_ALL_CHANNEL_SCAN
#endif

#if CONFIG_SAMPLE_IOT_WIFI_CONNECT_AP_BY_SIGNAL
    #define SAMPLE_IOT_WIFI_CONNECT_AP_SORT_METHOD    WIFI_CONNECT_AP_BY_SIGNAL
#elif CONFIG_SAMPLE_IOT_WIFI_CONNECT_AP_BY_SECURITY
    #define SAMPLE_IOT_WIFI_CONNECT_AP_SORT_METHOD    WIFI_CONNECT_AP_BY_SECURITY
#endif

#if CONFIG_SAMPLE_IOT_WIFI_AUTH_OPEN
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_OPEN
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WEP
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WEP
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA_PSK
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA2_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA2_PSK
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA_WPA2_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA_WPA2_PSK
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA2_ENTERPRISE
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA2_ENTERPRISE
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA3_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA3_PSK
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WPA2_WPA3_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WPA2_WPA3_PSK
#elif CONFIG_SAMPLE_IOT_WIFI_AUTH_WAPI_PSK
    #define SAMPLE_IOT_WIFI_SCAN_AUTH_MODE_THRESHOLD    WIFI_AUTH_WAPI_PSK
#endif /* if CONFIG_SAMPLE_IOT_WIFI_AUTH_OPEN */

#define SNTP_SERVER_FQDN                                "pool.ntp.org"
/*-----------------------------------------------------------*/

static const char * TAG = "sample_azureiot";

static bool g_timeInitialized = false;
/*-----------------------------------------------------------*/

extern void vStartDemoTask( void );
/*-----------------------------------------------------------*/

/*-----------------------------------------------------------*/
extern bool wifiConfigIsConnected();
bool xAzureSample_IsConnectedToInternet()
{
    return wifiConfigIsConnected();
}

/*-----------------------------------------------------------*/

static void time_sync_notification_cb( struct timeval * tv )
{
    ESP_LOGI( TAG, "Notification of a time synchronization event" );
    g_timeInitialized = true;
}
/*-----------------------------------------------------------*/

static void initialize_time()
{
    sntp_setoperatingmode( SNTP_OPMODE_POLL );
    sntp_setservername( 0, SNTP_SERVER_FQDN );
    sntp_set_time_sync_notification_cb( time_sync_notification_cb );
    sntp_init();

    ESP_LOGI( TAG, "Waiting for time synchronization with SNTP server" );

    while( !g_timeInitialized )
    {
		bool co = wifiConfigIsConnected();
		printf("wifi connection status  : %d\r\n", co);
        vTaskDelay( pdMS_TO_TICKS( 1000 ) );
		////edit///
		gate = false;
		////edit.....
    }
}
/*-----------------------------------------------------------*/
#include "global.h"
#include "iap_task.h"
#include "uart_task.h"
#include "ping_pong.h"
#include "wifi_config.h"
#include "azure_iap.h"
#include "flash_fatfs.h"

extern bool gate;
void checksum_flash_data(){
	
	// uint32_t start_flash = 0x00009000;
	// uint32_t finish_flash = 0x0000c000;
	// uint8_t storage_data[15];
// printf("version:%d\r\n",version);
	// printf("sample version:%d\r\n",sample_version);
	// esp_partition_t* part = malloc(sizeof(part)) ;
	const esp_partition_t *partition = esp_partition_find_first(ESP_PARTITION_TYPE_DATA,ESP_PARTITION_SUBTYPE_ANY,"otadata");
	assert(partition);
	// partition->address = 0x00000000;
	// part->address = start_flash;
	// part->size = finish_flash;
	// memcpy(&part->size, finish_flash,sizeof(finish_flash) ) ;
	// partition->size = 0x003ffff0;
	uint8_t storage_data[1];
	// for(uint32_t i = part->address; i <= part->size-sizeof(storage_data)-1; i += i- sizeof(storage_data)){
		
		for(uint16_t j = 0 ; j < partition->size ; j++){
			esp_partition_read(partition,j,storage_data,sizeof(storage_data));
			read_data += storage_data[0];
			// printf("data : %d\r\n",storage_data[0]);
		}
	// }
	printf("check.............. \"%ld\" (0x%" PRIx32 " bytes)\n", partition->address, partition->size);
	printf( "wrtriten data : %ld\r\n",read_data);

}

void uartTaskMessageCallback(uint8_t* msg,int32_t len){
	uint8_t type=msg[0];

	printf("get type: %d, len: %ld\r\n",type,len);

	//依照指令種類分類處理
	if(iapTaskCheckMessageType(type)){
		iapTaskHandleMessage(msg,len);
	}else if(pingPongCheckMessageType(type)){
		pingPongHandleMessage(msg,len);
	}else if(wifiConfigCheckMessageType(type)){
		wifiConfigHandleMessage(msg,len);
	}else if(azureIapCheckMessageType(type)){
		azureIapHandleMessage(msg,len);
	}

}

void startTasks(){
	
gpio_set_direction(GPIO_NUM_0,GPIO_MODE_OUTPUT);


	printf("startTasks fw ver:%04d\r\n",ESP32_FW_VER);

	iapTaskInit();
	uartTaskInit();
	wifiConfigInit();


	iapTaskStart();
	uartTaskStart();
}


void app_main( void )
{
	/// test

	checksum_flash_data();

	////
    printf("AAAAAA01\r\n");
    ESP_ERROR_CHECK( nvs_flash_init() );
	printf("nvs ........... %d\r\n", nvs_flash_init());
    

    initFlashFatfs();
    initLoadFileProcess();
    //ESP_ERROR_CHECK( esp_netif_init() );
    //ESP_ERROR_CHECK( esp_event_loop_create_default() );
    /*Allow other core to finish initialization */
    printf("AAAAAA02\r\n");
    vTaskDelay( pdMS_TO_TICKS( 100 ) );

    printf("AAAAAA03\r\n");
    startTasks();

    printf("AAAAAA04\r\n");
    initialize_time();

    printf("AAAAAA05\r\n");
    vStartDemoTask();

	
}
/*-----------------------------------------------------------*/

uint64_t ullGetUnixTime( void )
{
    time_t now = time( NULL );

    if( now == ( time_t ) ( -1 ) )
    {
        ESP_LOGE( TAG, "Failed obtaining current time.\r\n" );
    }

    return now;
}
/*---------------------------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------------------------*/
static AzureIoTHubClient_t* azureClientPtr=0;
int32_t azureState=-100;
//0=> azure ready
//-1=> azure not connected
//-100=> init
void awsRoutineHandleState(int32_t state){
    azureState=state;
}

void handleAwsC2dMessage(AzureIoTHubClientCloudToDeviceMessageRequest_t * pxMessage){
	if(azureClientPtr==0){
		return;
	}
    //( void ) pvContext;
    //LogInfo( ( "Cloud message payload : %.*s \r\n",
    //           ( int ) ,
    //           ( const char * )  ) );
			   
	int32_t cxtLen=pxMessage->ulPayloadLength;
	const uint8_t* cxt=pxMessage->pvMessagePayload;
	
	int32_t jsonStrLen=cxt[0];
	jsonStrLen<<=0;
	jsonStrLen+=cxt[1];
	
	if(jsonStrLen>cxtLen-2){
		return;//長度不符
	}
	
	const char* jsonPtr=(const char*)(cxt+2);
	const uint8_t* binPtr=cxt+2+jsonStrLen;
	uint32_t binSize=cxtLen-2-jsonStrLen;
	
    LogInfo( ( "Cloud message payload : %.*s \r\n",
               ( int )jsonStrLen,
               ( const char * )jsonPtr) );
	
	cJSON *root=cJSON_ParseWithLength(jsonPtr,jsonStrLen);
	
	if(cJSON_HasObjectItem(root,"resp_cmd")){
		cJSON* respCmdNode=cJSON_GetObjectItem(root,"resp_cmd");
		char* respCmd=cJSON_GetStringValue(respCmdNode);
		
		if(handleLoadFileResponse(respCmd,azureClientPtr,root,binPtr,binSize)){
			LogInfo( ("handle load file response"));
		}
	}
	
	
	cJSON_Delete(root);
}

void awsRoutineInit(AzureIoTHubClient_t* xAzureIoTHubClient){
	/* Create a bag of properties for the telemetry */
	xResult = AzureIoTMessage_PropertiesInit( &xPropertyBag, ucPropertyBuffer, 0, sizeof( ucPropertyBuffer ) );
	configASSERT( xResult == eAzureIoTSuccess );

	/* Sending a default property (Content-Type). */
	xResult = AzureIoTMessage_PropertiesAppend( &xPropertyBag,
												( uint8_t * ) AZ_IOT_MESSAGE_PROPERTIES_CONTENT_TYPE, sizeof( AZ_IOT_MESSAGE_PROPERTIES_CONTENT_TYPE ) - 1,
												( uint8_t * ) sampleazureiotMESSAGE_CONTENT_TYPE, sizeof( sampleazureiotMESSAGE_CONTENT_TYPE ) - 1 );
	configASSERT( xResult == eAzureIoTSuccess );

	/* Sending a default property (Content-Encoding). */
	xResult = AzureIoTMessage_PropertiesAppend( &xPropertyBag,
												( uint8_t * ) AZ_IOT_MESSAGE_PROPERTIES_CONTENT_ENCODING, sizeof( AZ_IOT_MESSAGE_PROPERTIES_CONTENT_ENCODING ) - 1,
												( uint8_t * ) sampleazureiotMESSAGE_CONTENT_ENCODING, sizeof( sampleazureiotMESSAGE_CONTENT_ENCODING ) - 1 );
	configASSERT( xResult == eAzureIoTSuccess );

	/* How to send an user-defined custom property. */
	//也許iot hub可以以此作為過濾條件
	xResult = AzureIoTMessage_PropertiesAppend( &xPropertyBag, ( uint8_t * ) "pkg_type", sizeof( "pkg_type" ) - 1,
												( uint8_t * ) "dfu", sizeof( "dfu" ) - 1 );
	configASSERT( xResult == eAzureIoTSuccess );
	
	azureClientPtr=xAzureIoTHubClient;
	
	
	//startLoadFile("esp",0x0100);
    //startUpdateFile("esp");
    //startUpdateFile("r3e-fpga");
}
void awsRoutineHandleLoop(){
	handleLoadFileStateFun(azureClientPtr);
}

