#include "azure_state_load_file.h"
#include <cJSON.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <global_var.h>
#include <azure_comm_cmd.h>

#include "esp_vfs_fat.h"
#include "flash_fatfs.h"
#include "uart_task.h"
#include "esp_log.h"
#include "util.h"

#include "azure_sample_connection.h"

static const char * TAG = "load_file";
LoadFileState espLoadFileState;

const char* verInfoFn="ver.txt";
char localFileName[64];

extern void sendAzureIapMsgToStm32(int32_t cmd,char* fid,uint8_t res,uint8_t* data,int32_t dataLen);
static void sendMsgToStm32(uint8_t res,uint8_t progress){
	sendAzureIapMsgToStm32((int32_t)0x32,espLoadFileState.fileId,res,&progress,1);
}


int32_t loadFileGetCurrentStatus(char* fn,int32_t* currLen,int32_t* totalLen){
	if(espLoadFileState.state<0){
		*fn=0;
		*currLen=0;
		*totalLen=0;
		return -1;
	}
	strcpy(fn,espLoadFileState.fileId);
	*currLen=espLoadFileState.currAddr;
	*totalLen=espLoadFileState.maxSize;
	
	return 0;
}

bool removeLocalFileInfo(const char* fileId){
	char verFn[64];
	buildFlashFileName(verInfoFn,verFn);

	struct stat st;
    if (stat(verFn, &st) == 0) {
    }else{
		return false;
	}

	char* tmpBuf=(char*)malloc(4096);
	FILE *f = fopen(verFn, "r");
	int32_t rCnt=fread(tmpBuf,1,4096,f);
	fclose(f);

	cJSON *root=cJSON_ParseWithLength(tmpBuf,rCnt);
	if(cJSON_HasObjectItem(root,fileId)){
		cJSON_DeleteItemFromObject(root,fileId);
	}else{
		free(tmpBuf);
		return false;
	}
	
	//write new json
	char* newJsonBuf=(char*)malloc(4096);
	memset(newJsonBuf,0,4096);
	
	cJSON_PrintPreallocated(root,newJsonBuf,4096,false);
	int32_t newJsonLen=strlen(newJsonBuf);

	cJSON_Delete(root);

	f = fopen(verFn, "w");
	fwrite(newJsonBuf,newJsonLen,1,f);
	fflush(f);
	fclose(f);

	free(tmpBuf);
	free(newJsonBuf);

	return true;
}

bool readLocalFileInfo(const char* fileId,int32_t* ver, int32_t* size,uint8_t* md5){
	char verFn[64];
	buildFlashFileName(verInfoFn,verFn);

	*ver=0;
	*size=0;

	struct stat st;
    if (stat(verFn, &st) == 0) {
    }else{
		return false;
	}

	char* tmpBuf=(char*)malloc(4096);
	FILE *f = fopen(verFn, "r");
	int32_t rCnt=fread(tmpBuf,1,4096,f);
	fclose(f);

	//{"esp":{"ver":257,"size":955616,"md5":"823464f27933672d80356d9075140115"},
	//"r3e-fpga":{"ver":257,"size":51200,"md5":"7582098515d083852cbe12863c18280c"}}

	cJSON *root=cJSON_ParseWithLength(tmpBuf,rCnt);
	if(cJSON_HasObjectItem(root,fileId)){
		cJSON* fidNode=cJSON_GetObjectItem(root,fileId);

		//檢查version，更新ver變數
		if(cJSON_HasObjectItem(fidNode,"ver")){
			cJSON* verNode=cJSON_GetObjectItem(fidNode,"ver");
			*ver=(int32_t)cJSON_GetNumberValue(verNode);
		}else{
			cJSON_Delete(root);
			free(tmpBuf);
			return false;
		}

		//檢查size
		if(cJSON_HasObjectItem(fidNode,"size")){
			cJSON* sizeNode=cJSON_GetObjectItem(fidNode,"size");
			*size=(int32_t)cJSON_GetNumberValue(sizeNode);
		}else{
			cJSON_Delete(root);
			free(tmpBuf);
			return false;
		}

		//檢查md5
		if(md5!=0){
			if(cJSON_HasObjectItem(fidNode,"md5")){
				cJSON* md5Node=cJSON_GetObjectItem(fidNode,"md5");
				char* md5Hex=cJSON_GetStringValue(md5Node);
				int32_t md5HexLen=strlen(md5Hex);

				//printf("get %s md5: %s\r\n",fileId,md5Hex);
				if(md5HexLen==32){
					hexToBytes(md5Hex,md5HexLen,md5);
				}else{
					ESP_LOGE( TAG, "%sfile id md5 hex is not 32: %ld",espLoadFileState.fileId,md5HexLen);
				}
				
			}else{
				cJSON_Delete(root);
				free(tmpBuf);
				return false;
			}
		}
		
	}else{
		cJSON_Delete(root);
		free(tmpBuf);
		return false;
	}
	
	cJSON_Delete(root);
	free(tmpBuf);

	return true;
}

bool startUpdateFile(const char* fileId){//AAAAAAAAAAAAA
	//讀取檔案，檢查版本
	int32_t ver=0;
	int32_t size=0;
    readLocalFileInfo(fileId,&ver,&size,0);

	printf("CUR STATE %ld\r\n",espLoadFileState.state);

	if(espLoadFileState.state>=0){
		//傳送訊息給stm
		return false;
	}

	espLoadFileState.currAddr=0;
	espLoadFileState.maxSize=0;
	espLoadFileState.localVer=ver;
	strcpy(espLoadFileState.fileId,fileId);

	printf("AAA CURR %s VER %ld SIZE %ld STATE %ld\r\n",espLoadFileState.fileId,espLoadFileState.localVer,espLoadFileState.maxSize,espLoadFileState.state);
	
	//sprintf(localFileName,"%s//%s.dat",basePath,fileId);
	buildFlashFileNameFromFileId(fileId,localFileName);
	espLoadFileState.state=0;
	
	return true;
}

bool startLoadFile(const char* fileId,uint32_t ver){
	if(espLoadFileState.state>=0){
		return false;
	}
	espLoadFileState.localVer=ver;
	strcpy(espLoadFileState.fileId,fileId);
	
	//sprintf(localFileName,"%s//%s.dat",basePath,fileId);
	buildFlashFileNameFromFileId(fileId,localFileName);
	espLoadFileState.state=0;
	
	return true;
}

static bool checkFileVer(AzureIoTHubClient_t* xAzureIoTHubClient){
	espLoadFileState.state=1;
	espLoadFileState.idleCnt=0;

	printf("BBB CURR %s VER %ld SIZE %ld STATE %ld\r\n",espLoadFileState.fileId,espLoadFileState.localVer,espLoadFileState.maxSize,espLoadFileState.state);
	
	return checkAzureFileVer(espLoadFileState.fileId,espLoadFileState.localVer,xAzureIoTHubClient);
}

static bool getFile(AzureIoTHubClient_t* xAzureIoTHubClient){
	uint32_t addr=espLoadFileState.currAddr;
	uint32_t size=espLoadFileState.maxSize-addr;
	if(size>32768){
		size=32768;
	}

	espLoadFileState.state=3;
	espLoadFileState.idleCnt=0;
	
	return checkAzureGetFile(espLoadFileState.fileId,addr,size,xAzureIoTHubClient);
}


static bool handleFileVer(AzureIoTHubClient_t* xAzureIoTHubClient,cJSON *root){
	if(espLoadFileState.state!=1){return false;}
	
	//{"resp_cmd": "dfu_check_ver_esp", "last_ver": 4660, "md5": "ca53b145e680898d44a2bb0da8d1580a", "req_update": true}
	cJSON* lastVerNode=cJSON_GetObjectItem(root,"last_ver");
	cJSON* sizeNode=cJSON_GetObjectItem(root,"size");
	cJSON* md5Node=cJSON_GetObjectItem(root,"md5");
	cJSON* reqUpdateNode=cJSON_GetObjectItem(root,"req_update");
	cJSON* fileIdNode=cJSON_GetObjectItem(root,"file_id");
		
	if(lastVerNode!=0 && sizeNode!=0 && md5Node!=0 && fileIdNode!=0 && reqUpdateNode!=0){		
		uint32_t ver=(int)cJSON_GetNumberValue(lastVerNode);
		uint32_t size=(int)cJSON_GetNumberValue(sizeNode);
		char* md5Hex=cJSON_GetStringValue(md5Node);
		char* fileIdStr=cJSON_GetStringValue(fileIdNode);
		bool reqUpdate=cJSON_IsTrue(reqUpdateNode);
		
		if(strcmp(fileIdStr,espLoadFileState.fileId)!=0){
			ESP_LOGE( TAG, "file id mismatch: %s %s",fileIdStr,espLoadFileState.fileId);
			return false;
		}
		
		int32_t md5HexLen=strlen(md5Hex);
		if(md5HexLen!=32){
			ESP_LOGE( TAG, "md5 str is not 32chars!!" );
			return false;
		}
				
		if(reqUpdate==false){
			//不用處理
			espLoadFileState.state=-1;
			espLoadFileState.azureVer=ver;
			espLoadFileState.currAddr=size;
			espLoadFileState.maxSize=size;

			//傳送訊息給stm32
			sendMsgToStm32(0,253);//表示不需要更新

			return true;

		}else{
			espLoadFileState.state=2;
			espLoadFileState.azureVer=ver;
			espLoadFileState.currAddr=0;
			espLoadFileState.maxSize=size;
			
			convertHexToBytes(md5Hex,md5HexLen,espLoadFileState.md5);
			
			//清空指定區域的flash
			remove(localFileName);

			//清除當前file ver紀錄
			removeLocalFileInfo(espLoadFileState.fileId);
			
			//起始化md5計算
			MD5Init(&(espLoadFileState.md5Ctx));
		}
	}
	return true;
}

static void updateVerFile(LoadFileState* state){
	char verFn[64];
	buildFlashFileName(verInfoFn,verFn);

	char* fileId=state->fileId;

	struct stat st;
	cJSON *root;

    if (stat(verFn, &st) == 0) {
		char* tmpBuf=(char*)malloc(4096);
		FILE *f = fopen(verFn, "r");
		int32_t rCnt=fread(tmpBuf,1,4096,f);
		fclose(f);

		root=cJSON_ParseWithLength(tmpBuf,rCnt);
		free(tmpBuf);
    }else{
		root=cJSON_CreateObject();
	}

	if(cJSON_HasObjectItem(root,fileId)){
		cJSON* fidNode=cJSON_GetObjectItem(root,fileId);
		cJSON* verNode=cJSON_GetObjectItem(fidNode,"ver");
		cJSON* sizeNode=cJSON_GetObjectItem(fidNode,"size");
		cJSON* md5Node=cJSON_GetObjectItem(fidNode,"md5");
		cJSON_SetNumberHelper(verNode,state->azureVer);
		cJSON_SetNumberHelper(sizeNode,state->maxSize);
		char md5Str[64];
		bytesToHex(state->md5,16,md5Str);
		cJSON_SetValuestring(md5Node,md5Str);
	}else{
		cJSON* fidNode=cJSON_CreateObject();
		cJSON* verNode=cJSON_CreateNumber(state->azureVer);
		cJSON* sizeNode=cJSON_CreateNumber(state->maxSize);
		char md5Str[64];
		bytesToHex(state->md5,16,md5Str);
		cJSON* md5Node=cJSON_CreateString(md5Str);

		cJSON_AddItemToObject(fidNode,"ver",verNode);
		cJSON_AddItemToObject(fidNode,"size",sizeNode);
		cJSON_AddItemToObject(fidNode,"md5",md5Node);
		cJSON_AddItemToObject(root,fileId,fidNode);
	}

	char* newJsonBuf=(char*)malloc(4096);
	memset(newJsonBuf,0,4096);
	
	cJSON_PrintPreallocated(root,newJsonBuf,4096,false);
	int32_t newJsonLen=strlen(newJsonBuf);

	cJSON_Delete(root);

	FILE *f = fopen(verFn, "w");
	fwrite(newJsonBuf,newJsonLen,1,f);
	fflush(f);
	fclose(f);

	free(newJsonBuf);
}


static bool handleLoadFile(AzureIoTHubClient_t* xAzureIoTHubClient,cJSON *root,const uint8_t* bin,uint32_t binSize){
	if(espLoadFileState.state!=3){return false;}
	
	cJSON* addrNode=cJSON_GetObjectItem(root,"addr");
	cJSON* sizeNode=cJSON_GetObjectItem(root,"size");
	cJSON* fileIdNode=cJSON_GetObjectItem(root,"file_id");

	if(addrNode!=0 && sizeNode!=0 && bin!=0 && fileIdNode!=0){
		uint32_t addr=(int)cJSON_GetNumberValue(addrNode);
		uint32_t size=(int)cJSON_GetNumberValue(sizeNode);
		char* fileIdStr=cJSON_GetStringValue(fileIdNode);

		if(espLoadFileState.currAddr==addr && size==binSize){//表示是最近指令要求的資料
			
			if(strcmp(fileIdStr,espLoadFileState.fileId)!=0){
				ESP_LOGE( TAG, "file id mismatch: %s %s",fileIdStr,espLoadFileState.fileId);
				return false;
			}

			ESP_LOGI( TAG, "write to file: %s %ld %ld",localFileName,espLoadFileState.currAddr,binSize);
		
			//將資料複製到flash
			FILE *f = fopen(localFileName, "wb");
			if(espLoadFileState.currAddr>0){
				fseek(f,espLoadFileState.currAddr,SEEK_SET);
			}
			fwrite(bin,binSize,1,f);
			fclose(f);
			
			//計算md5
			MD5Update(&(espLoadFileState.md5Ctx),(uint8_t*)bin,binSize);

			//傳送訊息給stm32
			int32_t progress=100*espLoadFileState.currAddr/espLoadFileState.maxSize;
			sendMsgToStm32(0,progress);
			
			//更新state
			espLoadFileState.state=2;//讓state machine可以接著讀下一個區段
			espLoadFileState.currAddr+=size;
			
			//檢查是否下載完畢
			if(espLoadFileState.currAddr==espLoadFileState.maxSize){
				uint8_t tmpMd5[16];
				MD5Final(tmpMd5,&(espLoadFileState.md5Ctx));
				int32_t cmpRes=memcmp(tmpMd5,espLoadFileState.md5,16);
				
				if(cmpRes==0){
					updateVerFile(&espLoadFileState);

					espLoadFileState.state=-1;//測試，讀完檔案停止
					ESP_LOGI( TAG, "esp fw ready, md5 correct" );

					//傳送訊息給stm32
					sendMsgToStm32(0,100);

				}else{
					ESP_LOGW( TAG, "esp fw error, md5 incorrect!" );

					//傳送訊息給stm32
					sendMsgToStm32(0,254);//表示md5錯誤

					return false;
				}
			}
		}else{
			//espLoadFileState.state=-1;//失敗就回歸idle
			ESP_LOGE( TAG, "esp fw addr or size mismatch addr: %lu, size: %lu, binSize: %lu",addr,size,binSize);
		}
	}
	return true;
}



void initLoadFileProcess(){
	initLoadFileState(&espLoadFileState);
	espLoadFileState.state=-1;

	//show version info
	char verFn[64];
	buildFlashFileName(verInfoFn,verFn);

	struct stat st;
    if (stat(verFn, &st) == 0) {
    }else{
		return;
	}

	char* tmpBuf=(char*)malloc(4096);
	memset(tmpBuf,0,4096);
	FILE *f = fopen(verFn, "r");
	int32_t rCnt=fread(tmpBuf,1,4096,f);
	fclose(f);
	

	for(int32_t i=0;i<rCnt;i++){
		if(tmpBuf[i]>0x80){
			remove(verFn);
			//檔案有問題，移除
			printf("ver file contains err!, remove it.\r\n");
			free(tmpBuf);
			return;
		}
	}




	printf("version file: %s %ld\r\n",verFn,rCnt);

	if(rCnt==0){
		remove(verFn);
	}

	int32_t msgLen=strlen(tmpBuf);
	if(msgLen>0){
		printf(tmpBuf);
	}
	printf("\r\n\r\n");
	
	free(tmpBuf);
}

bool handleLoadFileResponse(char* cmd,AzureIoTHubClient_t* xAzureIoTHubClient,cJSON *root,const uint8_t* bin,uint32_t binSize){
	if(strcmp(cmd,AZURE_CMD_CHECK_VER)==0){
		handleFileVer(xAzureIoTHubClient,root);
		return true;
	}else if(strcmp(cmd,AZURE_CMD_GET_FILE)==0){
		handleLoadFile(xAzureIoTHubClient,root,bin,binSize);
		return true;
	}
	return true;
}

void handleLoadFileStateFun(AzureIoTHubClient_t* xAzureIoTHubClient){

	switch(espLoadFileState.state){
		case 0:
			checkFileVer(xAzureIoTHubClient);
			break;
		case 1:
			espLoadFileState.idleCnt++;
			if(espLoadFileState.idleCnt>=10){
				espLoadFileState.state=0;
			}
			break;
		case 2:
			getFile(xAzureIoTHubClient);
			break;
		case 3:
			espLoadFileState.idleCnt++;
			if(espLoadFileState.idleCnt>=10){
				espLoadFileState.state=2;
			}
			break;
		case -1:
			//idle
			break;
	}
}
