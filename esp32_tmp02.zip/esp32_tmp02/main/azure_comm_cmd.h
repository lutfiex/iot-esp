#ifndef __AZURE_COMM_CMD__
#define __AZURE_COMM_CMD__

#include "azure_iot_hub_client.h"
#include <stdbool.h>

#define AZURE_CMD_CHECK_VER		"dfu_check_ver"
#define AZURE_CMD_GET_FILE		"dfu_get_file"

bool checkAzureFileVer(const char* fileId,uint32_t ver,AzureIoTHubClient_t* xAzureIoTHubClient);
bool checkAzureGetFile(const char* fileId,uint32_t addr,uint32_t size,AzureIoTHubClient_t* xAzureIoTHubClient);

int32_t convertHexToBytes(const char* hex,int32_t hexLen,uint8_t* res);

#endif