#include "global_var.h"

AzureIoTMessageProperties_t xPropertyBag;
AzureIoTResult_t xResult;
uint8_t ucPropertyBuffer[ 80 ];
uint8_t ucScratchBuffer[ 128 ];

uint8_t sample_version = ESP32_FW_VER;
uint8_t version = ESP32_FW_VER>>8;
uint32_t read_data = 0 ;

void initLoadFileState(LoadFileState* fs){
	fs->state=-1;//<0表示idle狀態
	fs->idleCnt=0;
	fs->azureVer=-1;
	fs->localVer=-1;
	fs->currAddr=0;
	fs->maxSize=0;
	fs->fileId[0]=0;
	memset(fs->md5,0,16);
	MD5Init(&(fs->md5Ctx));
}
