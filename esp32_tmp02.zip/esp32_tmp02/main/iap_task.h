#ifndef __JD_IAP_H__
#define __JD_IAP_H__

extern QueueHandle_t iapPkgNotifyQueue;
void iapTaskInit();
bool iapTaskCheckMessageType(uint8_t type);
void iapTaskHandleMessage(uint8_t* msg,int32_t len);
void iapTaskStart();

#endif