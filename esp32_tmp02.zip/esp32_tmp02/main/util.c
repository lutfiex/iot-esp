#include "util.h"
#include <string.h>
#include <stdio.h>

uint32_t utilLsbBytesToUint32(uint8_t* ba){
	uint32_t tmp=ba[3]&0x00ff;
	tmp<<=8;
	tmp |= ba[2];
	tmp<<=8;
	tmp |= ba[1];
	tmp<<=8;
	tmp |= ba[0];
	return tmp;
}

void utilUint32ToLsbBytes(uint8_t* ba,uint32_t val){
	*ba++ = (uint8_t)(val & 0x00ff);
	*ba++ = (uint8_t)((val>>8) & 0x00ff);
	*ba++ = (uint8_t)((val>>16) & 0x00ff);
	*ba = (uint8_t)((val>>24) & 0x00ff);
}

uint32_t utilMsbBytesToUint32(uint8_t* ba){
	uint32_t tmp=ba[0]&0x00ff;
	tmp<<=8;
	tmp |= ba[1];
	tmp<<=8;
	tmp |= ba[2];
	tmp<<=8;
	tmp |= ba[3];
	return tmp;
}

void utilUint32ToMsbBytes(uint8_t* ba,uint32_t val){
	*ba++ = (uint8_t)((val>>24) & 0x00ff);
	*ba++ = (uint8_t)((val>>16) & 0x00ff);
	*ba++ = (uint8_t)((val>>8) & 0x00ff);
	*ba = (uint8_t)((val) & 0x00ff);
}

void utilUint16ToMsbBytes(uint8_t* ba,uint16_t val){
	*ba++ = (uint8_t)((val>>8) & 0x00ff);
	*ba = (uint8_t)((val) & 0x00ff);
}

void utilPrepareUartMsg(UART_QUEUE_ITEM* uqi,uint8_t type,uint8_t errCode,const uint8_t* msg,int32_t msgLen){
	int32_t bufLen=2+msgLen;
    uqi->buf=(uint8_t*)malloc(bufLen);
    uqi->buf[0]=type;
	uqi->buf[1]=errCode;
	uqi->len=bufLen;

	printf("set buf ptr: %p\r\n",uqi->buf);

	printf("msg buf ptr: %ld\r\n",uqi->len);

	if(msgLen!=0 && msg!=0){
		memcpy(uqi->buf+2,msg,msgLen);
	}
}

void bytesToHex(uint8_t* bytes,int32_t bCnt,char* res){
	char* ptr=res;
	for(int32_t i=0;i<bCnt;i++){
		ptr+=sprintf(ptr,"%02x",bytes[i]);
	}*ptr=0;
}


uint8_t halfHexToByte(char c){
	if(c>='0' && c<='9'){
		return c-'0';
	}

	if(c>='a' && c<='f'){
		return c-'a'+10;
	}

	if(c>='A' && c<='F'){
		return c-'A'+10;
	}
	return 0;
}

uint8_t hexToByte(char* c){
	uint8_t res=halfHexToByte(c[0]);
	res<<=4;
	res |= halfHexToByte(c[1]);
	return res;
}

void hexToBytes(char* hex,int32_t hexLen,uint8_t* bytes){
	int32_t bCnt=hexLen/2;

	//printf("%s\r\n",hex);
	for(int32_t i=0;i<bCnt;i++){
		bytes[i]=hexToByte(hex);
		//printf("%c%c => %02x\r\n",hex[0],hex[1],bytes[i]);
		hex+=2;
		
	}
}