#include "flash_fatfs.h"
#include "esp_log.h"

#define EXAMPLE_FLASH_FREQ_MHZ      40

#define HOST_ID  SPI3_HOST
#define PIN_MISO 12
#define PIN_MOSI 13
#define PIN_CLK  14
#define PIN_CS   15
#define SPI_DMA_CHAN SPI_DMA_CH_AUTO

static const char *TAG = "flash_fatfs";

// Handle of the wear levelling library instance
static wl_handle_t s_wl_handle = WL_INVALID_HANDLE;

// Mount path for the partition
const char *basePath = "/extflash";

static esp_flash_t* auo_init_ext_flash(void)
{
    const spi_bus_config_t bus_config = {
        .mosi_io_num = PIN_MOSI,
        .miso_io_num = PIN_MISO,
        .sclk_io_num = PIN_CLK,
    };

    const esp_flash_spi_device_config_t device_config = {
        .host_id = HOST_ID,
        .cs_id = 0,
        .cs_io_num = PIN_CS,
        .io_mode = SPI_FLASH_DIO,
        .freq_mhz = EXAMPLE_FLASH_FREQ_MHZ,
    };

    ESP_LOGI(TAG, "Initializing external SPI Flash");
    ESP_LOGI(TAG, "Pin assignments:");
    ESP_LOGI(TAG, "MOSI: %2d   MISO: %2d   SCLK: %2d   CS: %2d",
        bus_config.mosi_io_num, bus_config.miso_io_num,
        bus_config.sclk_io_num, device_config.cs_io_num
    );

    // Initialize the SPI bus
    ESP_LOGI(TAG, "DMA CHANNEL: %d", SPI_DMA_CHAN);
    ESP_ERROR_CHECK(spi_bus_initialize(HOST_ID, &bus_config, SPI_DMA_CHAN));

    // Add device to the SPI bus
    esp_flash_t* ext_flash;
    ESP_ERROR_CHECK(spi_bus_add_flash_device(&ext_flash, &device_config));

    // Probe the Flash chip and initialize it
    esp_err_t err = esp_flash_init(ext_flash);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to initialize external Flash: %s (0x%x)", esp_err_to_name(err), err);
        return NULL;
    }

    // Print out the ID and size
    uint32_t id;
    ESP_ERROR_CHECK(esp_flash_read_id(ext_flash, &id));
    ESP_LOGI(TAG, "Initialized external Flash, size=%lu KB, ID=0x%lx", ext_flash->size / 1024, id);

    return ext_flash;
}

static const esp_partition_t* auo_add_partition(esp_flash_t* ext_flash, const char* partition_label)
{
    ESP_LOGI(TAG, "Adding external Flash as a partition, label=\"%s\", size=%lu KB", partition_label, ext_flash->size / 1024);
    const esp_partition_t* fat_partition;
    const size_t offset = 0;
    ESP_ERROR_CHECK(esp_partition_register_external(ext_flash, offset, ext_flash->size, partition_label, ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_FAT, &fat_partition));

    // Erase space of partition on the external flash chip
    ///ESP_LOGI(TAG, "Erasing partition range, offset=%u size=%lu KB", offset, ext_flash->size / 1024);
    //ESP_ERROR_CHECK(esp_partition_erase_range(fat_partition, offset, ext_flash->size));
    return fat_partition;
}

static void auo_list_data_partitions(void)
{
    ESP_LOGI(TAG, "Listing data partitions:");
    esp_partition_iterator_t it = esp_partition_find(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, NULL);

    for (; it != NULL; it = esp_partition_next(it)) {
        const esp_partition_t *part = esp_partition_get(it);
        ESP_LOGI(TAG, "- partition '%s', subtype %u, offset 0x%lx, size %lu kB",
        part->label, part->subtype, part->address, part->size / 1024);
    }

    esp_partition_iterator_release(it);
}

static bool auo_mount_fatfs(const char* partition_label)
{
    ESP_LOGI(TAG, "Mounting FAT filesystem");
    const esp_vfs_fat_mount_config_t mount_config = {
            .max_files = 4,
            .format_if_mount_failed = true,
            .allocation_unit_size = CONFIG_WL_SECTOR_SIZE
    };
    esp_err_t err = esp_vfs_fat_spiflash_mount_rw_wl(basePath, partition_label, &mount_config, &s_wl_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to mount FATFS (%s)", esp_err_to_name(err));
        return false;
    }
    return true;
}

bool initFlashFatfs(){
    // Set up SPI bus and initialize the external SPI Flash chip
    esp_flash_t* flash = auo_init_ext_flash();
    if (flash == NULL) {
        return false;
    }

    // Add the entire external flash chip as a partition
    const char *partition_label = "ext_flash";
    auo_add_partition(flash, partition_label);

    // List the available partitions
    auo_list_data_partitions();

    // Initialize FAT FS in the partition
    if (!auo_mount_fatfs(partition_label)) {
        return false;
    }

    // Print FAT FS size information
    uint64_t bytes_total, bytes_free;
    esp_vfs_fat_info(basePath, &bytes_total, &bytes_free);
    ESP_LOGI(TAG, "FAT FS: %lld kB total, %lld kB free", bytes_total / 1024, bytes_free / 1024);
	
	
	
	//測試
    struct stat st;
	char testFn[64];
	buildFlashFileNameFromFileId("esp",testFn);
	
    if (stat(testFn, &st) == 0) {
		ESP_LOGI(TAG, "find local esp.dat: %lu", st.st_size);
    }
	
	return true;
}

int32_t buildFlashFileName(const char* fn,char* buf){
	return sprintf(buf,"%s/%s",basePath,fn);
}

int32_t buildFlashFileNameFromFileId(const char* fnNoExt,char* buf){
	return sprintf(buf,"%s/%s.dat",basePath,fnNoExt);
}