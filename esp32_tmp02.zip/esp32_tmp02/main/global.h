#ifndef __JD_GLOBAL_H__
#define __JD_GLOBAL_H__

#include <stdint.h>

typedef struct{
	uint8_t* buf;
	uint32_t len;
}UART_QUEUE_ITEM;

#endif