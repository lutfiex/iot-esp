#ifndef __FLASH_FATFS_H__
#define __FLASH_FATFS_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "esp_flash.h"
#include "esp_flash_spi_init.h"
#include "esp_partition.h"
#include "esp_vfs.h"
#include "esp_vfs_fat.h"
#include "esp_system.h"
#include "soc/spi_pins.h"

extern const char *basePath;

bool initFlashFatfs();
int32_t buildFlashFileName(const char* fnNoExt,char* buf);
int32_t buildFlashFileNameFromFileId(const char* fnNoExt,char* buf);

#endif