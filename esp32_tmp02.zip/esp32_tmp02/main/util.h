#ifndef __JD_UTIL_H__
#define __JD_UTIL_H__

#include "global.h"
#include <stdint.h>

uint32_t utilLsbBytesToUint32(uint8_t* ba);
void utilUint32ToLsbBytes(uint8_t* ba,uint32_t val);

uint32_t utilMsbBytesToUint32(uint8_t* ba);
void utilUint32ToMsbBytes(uint8_t* ba,uint32_t val);

void utilUint16ToMsbBytes(uint8_t* ba,uint16_t val);

void utilPrepareUartMsg(UART_QUEUE_ITEM* uqi,uint8_t type,uint8_t errCode,const uint8_t* msg,int32_t msgLen);

void hexToBytes(char* hex,int32_t hexLen,uint8_t* bytes);
void bytesToHex(uint8_t* bytes,int32_t bCnt,char* res);

#endif