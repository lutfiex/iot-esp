#ifndef __JD_AZURE_IAP_H__
#define __JD_AZURE_IAP_H__

#include <stdint.h>
#include <stdbool.h>

bool azureIapCheckMessageType(uint8_t type);
void azureIapHandleMessage(uint8_t* msg,int32_t len);

#endif